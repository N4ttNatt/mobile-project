package com.example.projeto_mobile

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.projeto_mobile.api.ApiService
import com.example.projeto_mobile.api.MyData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var apiService: ApiService

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Retrofit
        val retrofit = Retrofit.Builder()
            .baseUrl("https://economia.awesomeapi.com.br/")  // Use your actual base URL
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        apiService = retrofit.create(ApiService::class.java)

        // Declarção
        val bottomtext = findViewById<TextView>(R.id.textoR)
        val buttonGetCurrency = findViewById<Button>(R.id.buttonCurrency)
        val spinnerOrigem = findViewById<Spinner>(R.id.CurrencySpinnerO)
        val spinnerDestino = findViewById<Spinner>(R.id.CurrencySpinnerD)

        val opcoes = listOf("BRL", "EUR", "USD")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, opcoes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item)
        spinnerOrigem.adapter = adapter
        spinnerDestino.adapter = adapter

        fun handleApiResponse(data: Map<String, MyData>?, currencyCode: String) {
            // Verifica se a data não é null e contém o par necessário
            val currencyKey = currencyCode
            val responseKey = currencyCode.replace("-","")
            val currencyValue = data?.get(responseKey)

            Log.d("Tag","${currencyValue?.bid}")

            if (currencyValue != null) {
                // Mostra o valor
                bottomtext.text = "$currencyCode: ${currencyValue.bid}"
            } else {
                // Caso não tenha informação da moeda
                bottomtext.text = "Conversion rate for $currencyCode not available."
            }
        }

        fun fetchCurrencyConversion(currencyCode: String) {
            // Chamada da API
            apiService.getCurrency(currencyCode).enqueue(object : Callback<Map<String, MyData>> {
                override fun onResponse(call: Call<Map<String, MyData>>, response: Response<Map<String, MyData>>) {
                    if (response.isSuccessful) {
                        val data = response.body()

                        // Resposta da API

                        handleApiResponse(data, currencyCode)

                    } else {
                        // Caso a resposta não tenha sucesso

                        val errorMsg = response.errorBody()?.string()
                        Log.e("API Error", "Error Body: $errorMsg")
                        bottomtext.text = "Error fetching conversion data."
                    }
                }

                override fun onFailure(call: Call<Map<String, MyData>>, t: Throwable) {
                    // Caso falha da API (erro de rede, etc)
                    Log.e("API Failure", "Failure: ${t.message}")
                    bottomtext.text = "Failed to get data: ${t.message}"
                }
            })
        }

        buttonGetCurrency.setOnClickListener {
            val enteredCurrencyCode = spinnerOrigem.selectedItem.toString().trim().toUpperCase() + "-" + spinnerDestino.selectedItem.toString().trim().toUpperCase()
            if (enteredCurrencyCode.isNotEmpty()) {
                // Faz a chamada da API baseado no código de moeda
                fetchCurrencyConversion(enteredCurrencyCode)
            } else {
                // Se o input estiver vazio
                bottomtext.text = "Please enter a valid currency code."
            }
        }

    }

}
