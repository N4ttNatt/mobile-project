package com.example.projeto_mobile.api

import retrofit2.http.GET
import retrofit2.Call
import retrofit2.http.Path

interface ApiService {

    @GET("json/last/{currency_code}?token=54e9c2f49df2a7dc4afbe7bdab4ff89ff59059b1a3865f98a8815c330df72809")
    fun getCurrency(@Path("currency_code") currencyCode: String): Call<Map<String, MyData>>

}